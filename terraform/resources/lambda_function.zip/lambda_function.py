import os
import json
import boto3

# Crear cliente SNS
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    try:
        # Obtener el ARN del tema SNS de las variables de entorno
        sns_topic_arn = os.environ['SNS_TOPIC_ARN']

        # Procesar cada mensaje recibido desde SQS
        for record in event['Records']:
            # Extraer el cuerpo del mensaje
            sqs_message = record['body']
            print(f"Mensaje de SQS recibido: {sqs_message}")

            # Publicar en SNS
            response = sns_client.publish(
                TopicArn=sns_topic_arn,
                Message=sqs_message,
                Subject='Mensaje desde Lambda'
            )
            print(f"Mensaje publicado en SNS. ID del mensaje: {response['MessageId']}")

        return {
            'statusCode': 200,
            'body': json.dumps('Mensajes procesados y publicados en SNS con éxito!')
        }
    except Exception as e:
        print(f"Error procesando mensajes: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error procesando los mensajes.')
        }

